# The Hidden Files — Sprint 7

## Added
- Expanded canon database
- 12 people
- 8 cases
- 26 records
- record type filtering
- trail history
- stronger Box 17 explorer
- stronger Traitor File trail

## Run
```bash
cd nextjs-app
npm install
npm run dev
```
