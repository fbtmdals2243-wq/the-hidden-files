import './globals.css'
export const metadata={title:'The Hidden Files Sprint 7'}
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang='ko'><body>{children}</body></html>}
