'use client'
import archive from '../data/archive.json'
import {useState} from 'react'

const tabs=['Dashboard','People','Cases','Records','Box 17','Timeline','Stats']
function allNodes(){return [...archive.people,...archive.cases,...archive.records]}
function findNode(id:string){return allNodes().find((x:any)=>x.id===id)}
function nodeType(x:any){if(x.name)return 'person'; if(x.year)return 'case'; return 'record'}

export default function Home(){
 const [tab,setTab]=useState('Dashboard'); const [query,setQuery]=useState(''); const [selected,setSelected]=useState<any|null>(null); const [results,setResults]=useState<any[]>([]); const [filter,setFilter]=useState('ALL'); const [trail,setTrail]=useState<string[]>([])
 function open(id:string){const n=findNode(id); if(n){setSelected(n); setTab('Viewer'); setTrail(t=>[...t.slice(-5),id])}}
 function search(){const q=query.toLowerCase(); const res=allNodes().filter((n:any)=>JSON.stringify(n).toLowerCase().includes(q)); setResults(res); setTab('Search')}
 return <div className="shell"><aside className="side"><div className="brand"><div className="mark">HF</div><h2>{archive.site.title}</h2><p className="muted">{archive.site.build} · {archive.site.restoration} restored</p><div className="bar"><div/></div></div><nav>{tabs.map(t=><button key={t} onClick={()=>setTab(t)} className={tab===t?'active':''}>{t}</button>)}</nav></aside>
 <main><div className="top"><input className="search" value={query} onChange={e=>setQuery(e.target.value)} onKeyDown={e=>{if(e.key==='Enter')search()}} placeholder="Search: EMP-0471, Lethe, Traitor, Box 17, Vault..."/><button className="btn" onClick={search}>SEARCH</button></div>
 {trail.length>0&&<div className="trail muted">Trail: {trail.map(id=><span key={id} className="node" onClick={()=>open(id)}>{id}</span>)}</div>}
 {tab==='Dashboard'&&<Dashboard open={open}/>}
 {tab==='People'&&<Index title="People" data={archive.people} open={open}/>}
 {tab==='Cases'&&<Index title="Cases" data={archive.cases} open={open}/>}
 {tab==='Records'&&<Records data={archive.records} open={open} filter={filter} setFilter={setFilter}/>}
 {tab==='Search'&&<Index title="Search Results" data={results} open={open}/>}
 {tab==='Viewer'&&selected&&<Viewer node={selected} open={open}/>}
 {tab==='Box 17'&&<Box17 open={open}/>}
 {tab==='Timeline'&&<Timeline open={open}/>}
 {tab==='Stats'&&<Stats/>}
 </main></div>
}
function Dashboard({open}:{open:(id:string)=>void}){return <div className="grid"><div className="card"><h1>Recovered Archive</h1><div className="grid3"><div><h2>{archive.people.length}</h2><p>People</p></div><div><h2>{archive.cases.length}</h2><p>Cases</p></div><div><h2>{archive.records.length}</h2><p>Records</p></div></div><p className="muted">Recommended trails</p><p><span className="node" onClick={()=>open('EMP-0471')}>EMP-0471</span><span className="node" onClick={()=>open('CASE-A23791')}>CASE-A23791</span><span className="node" onClick={()=>open('EVD-A23791-01')}>EVD-A23791-01</span><span className="node" onClick={()=>open('HR-2025-017')}>HR-2025-017</span></p><p><span className="node" onClick={()=>open('CASE-T00017')}>CASE-T00017</span><span className="node" onClick={()=>open('EMP-1021')}>EMP-1021</span><span className="node" onClick={()=>open('PHOTO-2027-022')}>PHOTO-2027-022</span></p></div><div className="terminal">{`ARCHIVE OS ONLINE
BUILD: SPRINT 7
FEATURE: FILTERED RECORDS
FEATURE: TRAIL HISTORY
FEATURE: EXPANDED CANON DATABASE
WARNING: TRAITOR FILE SEALED`}</div></div>}
function Index({title,data,open}:{title:string,data:any[],open:(id:string)=>void}){return <div className="card"><h1>{title}</h1><div className="list">{data.length?data.map((x:any)=><div className="item" key={x.id} onClick={()=>open(x.id)}><b>{x.id} · {x.name||x.title}</b><br/><span className="muted">{nodeType(x).toUpperCase()} · {x.classification||x.clearance||x.status}</span></div>):<p className="muted">No records found.</p>}</div></div>}
function Records({data,open,filter,setFilter}:{data:any[],open:(id:string)=>void,filter:string,setFilter:(s:string)=>void}){const types=['ALL',...Array.from(new Set(data.map((x:any)=>x.type)))]; const filtered=filter==='ALL'?data:data.filter((x:any)=>x.type===filter); return <div className="card"><h1>Records</h1><div className="filter">{types.map(t=><button key={t} onClick={()=>setFilter(t)} className={filter===t?'active':''}>{t}</button>)}</div><div className="list">{filtered.map((x:any)=><div className="item" key={x.id} onClick={()=>open(x.id)}><b>{x.id} · {x.title}</b><br/><span className="muted">{x.type} · {x.classification}</span></div>)}</div></div>}
function Viewer({node,open}:{node:any,open:(id:string)=>void}){const type=nodeType(node); return <div className="paper"><span className="stamp">{node.classification||node.clearance}</span><h1>{node.name||node.title}</h1><p><b>{node.summary}</b></p>{node.body&&<p>{node.body}</p>}<div className="kv"><b>ID</b><span>{node.id}</span>{type==='person'&&<><b>Role</b><span>{node.role}</span><b>Organization</b><span>{node.org}</span><b>Status</b><span>{node.status}</span></>}{type==='case'&&<><b>Year</b><span>{node.year}</span><b>Status</b><span>{node.status}</span><b>Lead</b><span><span className="node" onClick={()=>open(node.lead)}>{node.lead}</span></span></>}{type==='record'&&<><b>Type</b><span>{node.type}</span><b>Date</b><span>{node.date}</span><b>Subject</b><span><span className="node" onClick={()=>open(node.subject)}>{node.subject}</span></span></>}</div><h3>Recovered Links</h3>{(node.links||[]).map((id:string)=><span key={id} className="node" onClick={()=>open(id)}>{id}</span>)}</div>}
function Box17({open}:{open:(id:string)=>void}){const ids=['BOX17-INDEX','ARC-2048-017','EDU-2012-001','OWL-02081','WND-88201','PHOTO-2027-022','IA-2028-001']; return <div className="card"><h1>Box 17 Explorer</h1><p className="muted">Recovered physical traces linked to EMP-0471.</p><div className="boxgrid">{ids.map(id=><div className="artifact" key={id} onClick={()=>open(id)}>{id}<br/><small>{findNode(id)?.title}</small></div>)}</div></div>}
function Timeline({open}:{open:(id:string)=>void}){const items=[['2001','Ryu TaeO born in London.','EMP-0471'],['2012','Admission dossier opened.','EDU-2012-001'],['2025','Crown of Lethe closed.','CASE-A23791'],['2028','Traitor File sealed.','CASE-T00017'],['2048','Box 17 recovered.','BOX17-INDEX']]; return <div className="paper"><h1>Timeline</h1>{items.map(i=><p key={i[0]}><b>{i[0]}</b><br/>{i[1]} <span className="node" onClick={()=>open(i[2])}>{i[2]}</span></p>)}</div>}
function Stats(){const byType:any={}; archive.records.forEach((r:any)=>byType[r.type]=(byType[r.type]||0)+1); return <div className="grid"><div className="card"><h1>Archive Stats</h1>{Object.entries(byType).map(([k,v])=><p key={k}><b>{k}</b>: {v as number}</p>)}</div><div className="terminal">{`DATABASE HEALTH
PEOPLE: ${archive.people.length}
CASES: ${archive.cases.length}
RECORDS: ${archive.records.length}
BUILD TARGET: 100+ RECORDS`}</div></div>}
